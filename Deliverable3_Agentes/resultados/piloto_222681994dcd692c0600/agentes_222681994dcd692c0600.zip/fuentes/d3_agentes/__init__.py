"""D3 nuevo: agentes de investigación, redacción y auditoría sobre el corpus D2."""

__version__ = '0.1.0'
